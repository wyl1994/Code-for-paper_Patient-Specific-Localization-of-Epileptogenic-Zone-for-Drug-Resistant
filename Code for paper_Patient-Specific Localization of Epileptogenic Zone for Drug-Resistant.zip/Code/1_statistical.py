import numpy as np
import pandas as pd
import os
from os import path, listdir
from scipy.spatial.distance import pdist, squareform
from scipy.stats._stats_py import _unequal_var_ttest_denom
from sklearn import preprocessing

np.random.seed(42)
TARGET_PATIENTS = ['P001', 'P002', 'P003', 'P004', 'P005', 'P006', 'P007', 'P008', 'P009', 'P010', 'P011', 'P012']

COMMON_FEATURES = ['channel_means_outward', 'channel_means_inward', 'channel_min_outward', 'channel_max_outward',
                   'channel_min_inward', 'channel_max_inward', 'channel_outward_std', 'channel_inward_std']

ROOT_DIR = r"statistics"
BAD_CHANNEL_EXCEL = r"channel level EZ annotations.xlsx"
EXCEL_DIR = r"statistics_results"
os.makedirs(EXCEL_DIR, exist_ok=True)

ALPHA = 0.05
ALPHA_01 = 0.01
ALPHA_001 = 0.001
N_PERMUTATIONS = 10000  # Permutation number for PERMANOVA test


def normalize_matrix(matrix, by="column"):
    """Normalize matrix by row using z-score"""
    if by in ["row", "r", 0]:
        result = preprocessing.scale(matrix.T)
        result = result.T
        return result
    raise ValueError(f"Invalid value for {by}")


def convert_to_distance_matrix(matrix, metric="euclidean", norm="row", by="column"):
    """Compute distance matrix from feature matrix"""
    input_matrix = matrix.copy()
    if norm in ["row", "r", 0, "rows"]:
        input_values = normalize_matrix(input_matrix, "row")
    elif norm in ["column", "col", 1, "c", "columns"]:
        input_values = normalize_matrix(input_matrix, "column")
    else:
        input_values = input_matrix.values

    if by in ["column", "col", "c", 1]:
        input_matrix = input_matrix.T
        input_values = input_values.T
    vector = pdist(input_values, metric=metric)
    dis_matrix = squareform(vector)
    dis_df = pd.DataFrame(dis_matrix, columns=input_matrix.index, index=input_matrix.index)
    return dis_df


def calculate_degrees_freedom(matrix, item):
    """Calculate degrees of freedom for unequal variance t-test"""
    first_matrix = matrix.loc[item[0]][item[0]]
    second_matrix = matrix.loc[item[1]][item[1]]
    var_x = sum_square_dist(first_matrix)
    var_y = sum_square_dist(second_matrix)
    n_x = len(first_matrix)
    n_y = len(second_matrix)
    dof = _unequal_var_ttest_denom(var_x, n_x, var_y, n_y)[0]
    return dof


def Cohend(F, dof):
    """Calculate Cohen's d effect size"""
    cohend = 2 * (F / dof) ** 0.5
    return cohend


def sum_square_dist(distance_matrix):
    """Calculate average squared distance"""
    return distance_matrix.values.sum() / len(distance_matrix)


def F_stat(grouping, valid_distance):
    """Compute F statistic"""
    permuted_dismatrix = valid_distance.copy()
    permuted_dismatrix.columns = grouping
    permuted_dismatrix.index = grouping
    all_groups = list(set(grouping))
    SST = sum_square_dist(permuted_dismatrix)
    SSW = 0
    for group in all_groups:
        sub_slice = permuted_dismatrix.loc[group][group]
        SSW = SSW + sum_square_dist(sub_slice)
    N = len(permuted_dismatrix)
    a = len(all_groups)
    SSA = SST - SSW
    F = (SSA / (a - 1)) / (SSW / (N - a))
    return F


def PERMANOVA(valid_distance, grouping=None, permutations=9999):
    if grouping is None:
        grouping = valid_distance.columns
    np.random.seed(42)
    score = F_stat(grouping=grouping, valid_distance=valid_distance)
    perm_df = pd.DataFrame(index=range(permutations), columns=range(len(grouping)))
    perm_df = perm_df.apply(lambda series, grouping: np.random.permutation(grouping), axis=1, result_type="expand",
                            grouping=grouping)
    outcomes = perm_df.apply(F_stat, axis=1, valid_distance=valid_distance)
    pvalue = ((outcomes >= score).sum() + 1) / (permutations + 1)
    return pvalue, score


def permutational_analysis(data, mapping, column=None, **kwargs):
    input_matrix = data.copy()
    is_distance = kwargs.pop("dist", False)
    by = kwargs.pop("by", "column")
    norm = kwargs.pop("norm", "row")
    metric = kwargs.pop("metric", "euclidean")
    permutations = kwargs.pop("permutations", 9999)

    if by in ["column", 1, "col", "c"]:
        by = "column"
    elif by in ["row", "r", 0]:
        by = "row"
    sample_group_mapping = mapping
    if by == "column":
        input_matrix.columns = input_matrix.columns.map(sample_group_mapping)
    if by == "row":
        input_matrix.index = input_matrix.index.map(sample_group_mapping)
    if not is_distance:
        distance_matrix = convert_to_distance_matrix(input_matrix, metric=metric, norm=norm, by=by)
    else:
        distance_matrix = input_matrix.copy()

    distance_matrix = distance_matrix * distance_matrix
    pvalue, F = PERMANOVA(distance_matrix, permutations=permutations)
    dof = calculate_degrees_freedom(distance_matrix, ['EZ', 'NEZ'])
    cohend = Cohend(F, dof)
    return pvalue, F, cohend


def load_patient_period_data(patient_id, period):
    """Load EZ and NEZ data for one patient and one period"""
    bad_channel_dict = {}
    try:
        df_bad = pd.read_excel(BAD_CHANNEL_EXCEL)
        for _, row in df_bad.iterrows():
            pid = str(row['Patient ID']).strip().upper()
            s = str(row['Deleted Channels \n(Bad contacts)']).strip()
            bad_channel_dict[pid] = set(int(x) for x in s.split()) if s.lower() != 'nan' else set()
    except:
        bad_channel_dict[patient_id.upper()] = set()

    ez, nez = [], []
    period_path = path.join(ROOT_DIR, period)
    if not path.exists(period_path):
        return np.array(ez), np.array(nez)

    for file in listdir(period_path):
        if not file.endswith('.xlsx') or file.startswith('~$'):
            continue
        parts = file.replace('.xlsx', '').split('_')
        if len(parts) < 5 or parts[0].upper() != patient_id.upper():
            continue
        rt = parts[-2].lower()
        try:
            df = pd.read_excel(path.join(period_path, file))
            df.columns = df.columns.str.strip().str.replace(' ', '_')
            if f'{rt}_channel' in df.columns:
                df['Channel'] = pd.to_numeric(df[f'{rt}_channel'].astype(str).str.strip(), errors='coerce').fillna(
                    0).astype(int)
                df = df[~df['Channel'].isin(bad_channel_dict.get(patient_id.upper(), set()))]
            for f in COMMON_FEATURES:
                if f'{rt}_{f}' in df.columns:
                    df[f] = df[f'{rt}_{f}'].fillna(df[f'{rt}_{f}'].mean())
                else:
                    df[f] = np.nan
            df = df[COMMON_FEATURES].fillna(df.mean()).dropna()
            if rt == 'ez':
                ez.extend(df.values)
            else:
                nez.extend(df.values)
        except:
            continue
    return np.array(ez), np.array(nez)


def run_permanova_analysis(ez_data, nez_data, n_permutations=5000):
    if ez_data.size == 0 or nez_data.size == 0:
        return np.nan, np.nan, np.nan
    if ez_data.shape[1] != nez_data.shape[1]:
        return np.nan, np.nan, np.nan
    n_ez, n_nez = len(ez_data), len(nez_data)
    if n_ez < 3 or n_nez < 3:
        return np.nan, np.nan, np.nan
    ez_df = pd.DataFrame(ez_data, columns=COMMON_FEATURES)
    nez_df = pd.DataFrame(nez_data, columns=COMMON_FEATURES)
    combined_df = pd.concat([ez_df, nez_df], axis=0, ignore_index=True)
    group_labels = ['EZ'] * n_ez + ['NEZ'] * n_nez
    combined_df_T = combined_df.T
    combined_df_T.columns = [f'sample_{i}' for i in range(len(group_labels))]
    sample_mapping = dict(zip(combined_df_T.columns, group_labels))
    p_val, f_stat, cohend = permutational_analysis(
        data=combined_df_T,
        mapping=sample_mapping,
        by='column',
        norm='row',
        metric='euclidean',
        permutations=n_permutations
    )
    return p_val, f_stat, cohend


def statistical_analysis(period):
    all_res = []
    for pid in TARGET_PATIENTS:
        ez, nez = load_patient_period_data(pid, period)
        permanova_p, f_stat, cohend = run_permanova_analysis(ez, nez, n_permutations=N_PERMUTATIONS)
        print(f"{pid} ({period}) → p={permanova_p:.5f} | F={f_stat:.2f} | Cohen's d={cohend:.3f}")
        all_res.append({
            'Patient': pid,
            'Period': period,
            'p_value': permanova_p,
            'F_statistic': f_stat,
            'cohen_d': cohend,
            'significant_0.05': permanova_p < ALPHA if not np.isnan(permanova_p) else False,
            'significant_0.01': permanova_p < ALPHA_01 if not np.isnan(permanova_p) else False,
            'significant_0.001': permanova_p < ALPHA_001 if not np.isnan(permanova_p) else False
        })
    df_result = pd.DataFrame(all_res)
    df_result.to_excel(path.join(EXCEL_DIR, f'statistical_result_{period}.xlsx'), index=False)
    return df_result


if __name__ == "__main__":
    df_ictal = statistical_analysis('ictal')
    df_interictal = statistical_analysis('interictal')