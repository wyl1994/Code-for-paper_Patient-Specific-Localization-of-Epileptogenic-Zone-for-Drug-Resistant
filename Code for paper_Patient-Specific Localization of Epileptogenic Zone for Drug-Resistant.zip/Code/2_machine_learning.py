import os
import warnings
import pandas as pd
import numpy as np
from imblearn.over_sampling import SMOTE
from imblearn.under_sampling import RandomUnderSampler
from imblearn.combine import SMOTEENN
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from xgboost import XGBClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.neural_network import MLPClassifier
from lightgbm import LGBMClassifier
from sklearn.metrics import precision_score, recall_score, accuracy_score
from sklearn.metrics import roc_auc_score, f1_score, confusion_matrix
warnings.filterwarnings("ignore")

TARGET_PATIENTS = ['P001', 'P002', 'P003', 'P004', 'P005', 'P006', 'P007', 'P008', 'P009', 'P010', 'P011', 'P012']
FEATURE_NAMES = ['channel_means_outward', 'channel_means_inward', 'channel_min_outward', 'channel_max_outward',
                 'channel_min_inward', 'channel_max_inward', 'channel_outward_std', 'channel_inward_std']
DATA_ROOT = r"statistics"


def load_bad_channels():
    """Load bad channel list from Excel file"""
    bad_channel_map = {}
    try:
        df = pd.read_excel(r"channel level EZ annotations.xlsx")
        for _, row in df.iterrows():
            patient_id = str(row['Patient ID']).strip().upper()
            channel_str = str(row['Deleted Channels \n(Bad contacts)']).strip()
            if channel_str and channel_str.lower() != 'nan':
                bad_channel_map[patient_id] = {int(x) for x in channel_str.split() if x.isdigit()}
            else:
                bad_channel_map[patient_id] = set()
    except Exception as e:
        print(f"{e}")
    return bad_channel_map


def load_dataset(mode):
    """Load EZ and NEZ data for ictal, interictal or combined periods"""
    bad_channels = load_bad_channels()
    ictal_data_list = []
    interictal_data_list = []

    for period in ['ictal', 'interictal']:
        period_path = os.path.join(DATA_ROOT, period)
        if not os.path.exists(period_path):
            continue
        for file in os.listdir(period_path):
            if not file.endswith('.xlsx') or file.startswith('~$'):
                continue
            file_path = os.path.join(period_path, file)
            parts = file.replace('.xlsx', '').split('_')
            if len(parts) < 5:
                continue
            patient_id = parts[0].upper()
            if patient_id not in TARGET_PATIENTS:
                continue
            region_type = parts[-2].lower()
            label = 1 if region_type == 'ez' else 0
            channel_col = f"{region_type}_channel"

            try:
                df = pd.read_excel(file_path)
                df.columns = df.columns.str.strip().str.replace(' ', '_')
                if channel_col not in df.columns:
                    continue
                df['Channel'] = df[channel_col].astype(str).str.strip()
                for feat in FEATURE_NAMES:
                    original_col = f"{region_type}_{feat}"
                    df[feat] = df[original_col] if original_col in df.columns else np.nan
                df['Patient'] = patient_id
                df['Seizure'] = parts[1].lower()
                df['label'] = label
                df = df[FEATURE_NAMES + ['Patient', 'Seizure', 'label', 'Channel']]
                if patient_id in bad_channels:
                    df = df[~df['Channel'].astype(int).isin(bad_channels[patient_id])]
                if period == 'ictal':
                    ictal_data_list.append(df)
                else:
                    interictal_data_list.append(df)
            except:
                continue

    ictal_df = pd.concat(ictal_data_list, ignore_index=True) if ictal_data_list else pd.DataFrame()
    interictal_df = pd.concat(interictal_data_list, ignore_index=True) if interictal_data_list else pd.DataFrame()

    if mode == 'ictal':
        return ictal_df
    elif mode == 'interictal':
        return interictal_df
    else:
        if ictal_df.empty or interictal_df.empty:
            return pd.DataFrame()
        ictal_df = ictal_df.add_prefix('ictal_')
        interictal_df = interictal_df.add_prefix('inter_')
        for col in ['Patient', 'Seizure', 'Channel', 'label']:
            ictal_df[col] = ictal_df[f'ictal_{col}'].astype(str)
            interictal_df[col] = interictal_df[f'inter_{col}'].astype(str)
        combined_df = pd.merge(ictal_df, interictal_df, on=['Patient', 'Seizure', 'Channel', 'label'], how='inner')
        return combined_df


def preprocess_features(dataframe, mode):
    """Missing value imputation and data cleaning"""
    if dataframe.empty:
        return pd.DataFrame(), pd.Series(), [], pd.Series()
    dataframe = dataframe[dataframe['Patient'].isin(TARGET_PATIENTS)]
    if mode in ['ictal', 'interictal']:
        feature_columns = FEATURE_NAMES
    else:
        feature_columns = [f'ictal_{f}' for f in FEATURE_NAMES] + [f'inter_{f}' for f in FEATURE_NAMES]
    dataframe = dataframe[feature_columns + ['label', 'Patient']]
    dataframe = dataframe[dataframe[feature_columns].notna().sum(axis=1) > 0]
    for col in feature_columns:
        if dataframe[col].isna().any():
            dataframe[col] = dataframe[col].fillna(dataframe[col].mean())

    print(f"Preprocessing done: {len(feature_columns)} features, {len(dataframe)} samples")
    return dataframe[feature_columns], dataframe['label'].astype(int), feature_columns, dataframe['Patient']


def get_classifiers():
    """11 classification models"""
    models = {
        'SVM': SVC(probability=True, random_state=42, class_weight='balanced'),
        'XGBoost': XGBClassifier(random_state=42, eval_metric='logloss'),
        'RF': RandomForestClassifier(random_state=42, class_weight='balanced'),
        'LR': LogisticRegression(random_state=42, max_iter=1000),
        'KNN': KNeighborsClassifier(),
        'DT': DecisionTreeClassifier(random_state=42),
        'NB': GaussianNB(),
        'AdaBoost': AdaBoostClassifier(random_state=42),
        'LDA': LinearDiscriminantAnalysis(),
        'MLP': MLPClassifier(max_iter=1000, random_state=42),
        'LGBM': LGBMClassifier(random_state=42)
    }
    return models


def get_sampling_methods():
    """Data resampling methods for class imbalance"""
    samplers = {
        'Over': SMOTE(random_state=42),
        'Under': RandomUnderSampler(random_state=42),
        'Mixed': SMOTEENN(random_state=42)
    }
    return samplers


def compute_metrics(y_true, y_pred, y_proba=None):
    """Calculate comprehensive classification performance metrics"""
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, zero_division=0)
    sensitivity = recall_score(y_true, y_pred, zero_division=0)
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
    f1 = f1_score(y_true, y_pred, zero_division=0)
    auc = roc_auc_score(y_true, y_proba) if (y_proba is not None and len(np.unique(y_true)) > 1) else 0.5
    return {
        'accuracy': round(accuracy, 4),
        'precision': round(precision, 4),
        'sensitivity': round(sensitivity, 4),
        'specificity': round(specificity, 4),
        'f1': round(f1, 4),
        'auc': round(auc, 4)
    }


def leave_one_patient_cv(X, y, patient_labels, mode):
    """Leave-one-patient-out cross validation"""
    results = []
    unique_patients = sorted(patient_labels.unique())
    if len(unique_patients) < 2:
        return pd.DataFrame()
    models = get_classifiers()
    samplers = get_sampling_methods()
    for fold, test_patient in enumerate(unique_patients, 1):
        print(f"Fold {fold}/{len(unique_patients)} - Test: {test_patient}")
        train_mask = patient_labels != test_patient
        test_mask = patient_labels == test_patient
        X_train, y_train = X[train_mask].values, y[train_mask].values
        X_test, y_test = X[test_mask].values, y[test_mask].values
        if len(X_train) == 0 or len(X_test) == 0 or len(np.unique(y_train)) < 2:
            continue
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)

        for model_name, model in models.items():
            for sampler_name, sampler in samplers.items():
                try:
                    X_resampled, y_resampled = sampler.fit_resample(X_train_scaled, y_train)
                    model.fit(X_resampled, y_resampled)
                    if hasattr(model, 'predict_proba'):
                        y_proba = model.predict_proba(X_test_scaled)[:, 1]
                        best_f1 = 0
                        best_threshold = 0.5
                        for threshold in np.linspace(0.2, 0.7, 10):
                            y_pred = (y_proba >= threshold).astype(int)
                            current_f1 = f1_score(y_test, y_pred, zero_division=0)
                            if current_f1 > best_f1:
                                best_f1 = current_f1
                                best_threshold = threshold
                        y_pred = (y_proba >= best_threshold).astype(int)
                    else:
                        y_pred = model.predict(X_test_scaled)
                        y_proba = None
                        best_threshold = 0.5

                    metrics = compute_metrics(y_test, y_pred, y_proba)
                    results.append({
                        'Model': model_name,
                        'Sampler': sampler_name,
                        'Precision': metrics['precision'],
                        'Recall': metrics['sensitivity'],
                        'Specificity': metrics['specificity'],
                        'Accuracy': metrics['accuracy'],
                        'AUC': metrics['auc'],
                        'F1': metrics['f1'],
                        'Test_Patient': test_patient,
                        'Best_Threshold': best_threshold
                    })
                except Exception as e:
                    print(f"Error {model_name}+{sampler_name}: {str(e)[:30]}")
                    continue
    return pd.DataFrame(results)


def save_and_analyze(results, mode):
    """Save results and compute mean±std"""
    raw_output = f"L1_results_{mode}.xlsx"
    results.to_excel(raw_output, index=False)
    df = pd.read_excel(raw_output)
    metric_cols = ['Precision', 'Recall', 'Specificity', 'Accuracy', 'AUC', 'F1']
    def mean_std_format(series):
        return f"{series.mean():.2f}±{series.std(ddof=0):.2f}"

    summary = df.groupby(['Sampler', 'Model'])[metric_cols].agg(mean_std_format).reset_index()
    summary.to_excel(f"L1_analysis_{mode}.xlsx", index=False)
    print(summary.to_string(index=False))


if __name__ == "__main__":
    analysis_mode = 'ictal'  # Options: ictal / interictal / combined
    print(f"Analysis Mode: {analysis_mode}")
    dataset = load_dataset(analysis_mode)
    X_features, y_labels, _, patient_ids = preprocess_features(dataset, analysis_mode)
    cv_results = leave_one_patient_cv(X_features, y_labels, patient_ids, analysis_mode)
    save_and_analyze(cv_results, analysis_mode)